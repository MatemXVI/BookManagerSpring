package com.example.BookManagerSpring;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookManagerSpringApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(BookManagerSpringApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		BookManagerApp app = new BookManagerApp();
		app.info();
		boolean isRunning = true;
		while(isRunning){
//			if(!app.refresh())
//				System.out.println("Nie udało nawiązać się połaczenia z bazą danych");
			app.refresh();
			app.menu();
			int option = app.option();
			switch(option){
				case 1:
					app.addBook();
					break;
				case 2:
					app.findAllBooks();
					break;
				case 3:
					app.findBookByTitle();
					break;
				case 4:
					app.removeBook();
					break;
				case 5:
					app.refresh();
					break;
				case 0:
					if (app.quit()) {
						isRunning = false;
					}
					break;
				default:
					System.out.println("Podano niepoprawną wartość.");
			}
		}
	}
}
